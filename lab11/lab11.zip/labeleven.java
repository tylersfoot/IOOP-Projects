/**
 * Lab 11
 *
 * @author (Tyler Depa)
 * @version (v1.0 11-23-2023)
 */
public class labeleven {
    public static void main(String[] args) {
        P1();
    }
    
    public static void P1() {
        new CanvasFrame(); // construct the window, which will construct a frame (window), and a panel(canvas)
    }
}
